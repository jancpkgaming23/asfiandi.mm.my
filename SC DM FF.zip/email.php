<!-- REEDIT BY KEVIN GANS-->
<?php
$emailku = 'kevgansss@gmail.com';//GANTI EMAIL LU DISINI.
?>